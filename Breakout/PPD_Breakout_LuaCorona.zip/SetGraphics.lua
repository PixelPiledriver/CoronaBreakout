-- set nearest neighbor scaling
-- for crispy pixel goodness.
display.setDefault( "magTextureFilter", "nearest")
display.setDefault( "minTextureFilter", "nearest")