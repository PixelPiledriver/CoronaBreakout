
local physics = require("physics")

-- sprite
local spriteSheet = require("SpriteSheet")
local spriteData =
{
	name = "idle",
	frames = {5}
}

-- create a wall object
local function CreateWall(data)
	local obj = display.newSprite( spriteSheet, spriteData )

	obj.name = data.name or "wall"
	obj.anchorX = 0
	obj.anchorY = 0
	obj.x = data.x
	obj.y = data.y
	obj.width = data.width or obj.width
	obj.height = data.height or obj.height


	physics.addBody( obj, "static", {friction=0.4, bounce=0.8} )

	return obj
end

-- create objects
local wallLeft = CreateWall
{
	x = 0,
	y = 0,
	height = display.contentHeight
}

local wallRight = CreateWall
{
	x = display.contentWidth - wallLeft.width, 
	y = 0,
	height = display.contentHeight
}

local wallTop = CreateWall
{
	name = "ceiling",
	x = 0,
	y = 0,
	width = display.contentWidth
}

